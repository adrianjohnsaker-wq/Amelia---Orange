# Cybergothic Numogram: junction observer laboratory

This is an isolated copy of the research prototype, with a passive provenance observer, fixed cohort runner, five gate records and a resumable development checkpoint. It is separate from Amelia Orange. See `OBSERVER_INTEGRATION_REPORT_2026-11-15.md` for what was tested, and `COHORT_SEAL_ADDENDUM_2026-11-15.md` with the original protocol for the sealed plan.

## Recheck the development checkpoint

Python 3.12 and the standard library are sufficient for ordinary inspection; the isolated cohort workers additionally need Linux and `libseccomp.so.2`. In this directory:

```bash
python -B shadow_cli.py status --db example_paired_checkpoint.sqlite
python -B shadow_cli.py resume --db example_paired_checkpoint.sqlite --output resumed.sqlite --until 116.43421723941793
```

The exact horizon is stored in `example_paired_checkpoint_manifest.json`. Check the resulting state, event and shadow hashes, and classification, against that manifest. The command creates a new file and refuses to overwrite it. The checkpoint uses historical development seed 45003, not a future cohort seed.

## Evidence and reproduction

`gate_results/gate_1_invariance.json` through `gate_5_isolation.json` contain the five gate results; `development_pilot.json` contains separate feasibility diagnostics. The verified direct and vector rehearsal directories retain the original pre-dispatch SQLite files in gzip form, five full compressed primary/observer records, manifests, analysis output and archive audits. Use `python -B audit_cohort_archive.py --run-dir cohort_runs/verified_direct` or `verified_vector` to re-audit. The small rehearsal outcomes are not cohort results.

The complete gate commands are `python -B gate_invariance.py`, `python -B gate_paths.py`, `python -B gate_checkpoint.py`, and `python -B gate_isolation.py`; `python -B development_pilot.py` runs the separate 40-seed feasibility screen. These overwrite gate records. To preserve the seal, first make a copy of the whole directory and run checks in that copy. `python -B -m unittest -q test_observer_paths test_nonchimeric test_analysis` runs the directed implementation and analysis tests.

`FINAL_COHORT_SEAL.json` is the local hash seal. The real cohort has not been run. The fixed runner would be invoked explicitly as `python -B cohort.py --name <new-name>`; without `--development` it checks the seal and cannot override the registered seed range or sample target. Development mode is restricted to at most three seeds outside that range. Run output is under a new `cohort_runs/<new-name>` directory. `cohort_analysis.py` and `match_nonchimeric.py` accept `--run-dir`; `audit_cohort_archive.py` verifies saved records.

Do not put Amelia credentials, live data or databases in this directory. The model workers clear their environment, enforce path restrictions, and block network/file-opening syscalls during the run. Source changes require new tests and a new local seal.
