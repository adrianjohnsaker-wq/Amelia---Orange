import { createHash } from 'node:crypto';
import { readFileSync, readdirSync, writeFileSync } from 'node:fs';
import { join } from 'node:path';

const [a, b, output] = process.argv.slice(2);
if (!a || !b || !output) throw new Error('Usage: node compare_replay.mjs FIRST_DIR SECOND_DIR OUTPUT_JSON');
const sha = bytes => createHash('sha256').update(bytes).digest('hex');
const sort = value => Array.isArray(value) ? value.map(sort) :
  value && typeof value === 'object' ? Object.fromEntries(Object.keys(value).sort().map(k => [k, sort(value[k])])) : value;
const encode = value => JSON.stringify(sort(value));

function readRun(dir) {
  const receipt = JSON.parse(readFileSync(dir + '.receipt.json', 'utf8'));
  const raw = readFileSync(join(dir, 'events.jsonl'), 'utf8');
  if (!raw.endsWith('\n')) throw new Error('Partial journal');
  const records = raw.slice(0, -1).split('\n').map(line => JSON.parse(line));
  let previous = null;
  const used = new Set();
  for (let i = 0; i < records.length; i++) {
    const r = records[i], { recordHash, ...body } = r;
    if (r.sequence !== i + 1 || r.previousHash !== previous || sha(encode(body)) !== recordHash) throw new Error('Invalid chain');
    if (r.checkpoint) {
      const ref = r.checkpoint;
      if (ref.file !== 'checkpoints/' + ref.sha256 + '.json') throw new Error('Invalid checkpoint path');
      const bytes = readFileSync(join(dir, ref.file));
      if (bytes.length !== ref.byteLength || sha(bytes) !== ref.sha256) throw new Error('Invalid checkpoint hash');
      used.add(ref.sha256 + '.json');
    }
    previous = recordHash;
  }
  if (previous !== receipt.head || records[0].kind !== 'RUN_STARTED' || records.at(-1).kind !== 'RUN_FINISHED') throw new Error('Receipt or completeness mismatch');
  if (readdirSync(join(dir, 'checkpoints')).some(f => !used.has(f))) throw new Error('Orphan checkpoint');
  return { records, receipt };
}

const x = readRun(a), y = readRun(b);
if (x.records.length !== y.records.length) throw new Error('Different record counts');
let sameData = 0, sameStates = 0;
for (let i = 0; i < x.records.length; i++) {
  const p = x.records[i], q = y.records[i];
  if (p.kind !== q.kind || encode(p.data) !== encode(q.data)) throw new Error('Different event data at record ' + (i + 1));
  sameData++;
  if (Boolean(p.checkpoint) !== Boolean(q.checkpoint)) throw new Error('Different checkpoint schedule');
  if (p.checkpoint) {
    const cp = JSON.parse(readFileSync(join(a, p.checkpoint.file), 'utf8'));
    const cq = JSON.parse(readFileSync(join(b, q.checkpoint.file), 'utf8'));
    for (const c of [cp, cq]) for (const snapshot of c.runtime.snapshots ?? []) delete snapshot.timestamp;
    if (encode(cp) !== encode(cq)) throw new Error('Different scientific state at record ' + (i + 1));
    sameStates++;
  }
}
const result = {
  schema: 'sxi.engineering-replay-comparison/v1',
  status: 'PASS',
  independentlyStartedProcesses: 2,
  matchingEventDataRecords: sameData,
  matchingFullCheckpointsAfterRemovingRuntimeSnapshotWallTimes: sameStates,
  originalLedgerHead: x.receipt.head,
  replayLedgerHead: y.receipt.head,
  note: 'The two chain heads differ because record and runtime snapshot timestamps differ; this is an engineering fixture, not a scientific discovery.',
};
writeFileSync(output, JSON.stringify(result, null, 2) + '\n', { flag: 'wx' });
console.log(JSON.stringify(result, null, 2));

